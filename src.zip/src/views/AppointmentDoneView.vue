<template>
  <AppointmentDoneBlock></AppointmentDoneBlock>
</template>

<script>
import AppointmentDoneBlock from "@/components/AppointmentDoneBlock";
export default {
  name: 'AppointmentDoneView',
  components: {
    AppointmentDoneBlock
  }
}
</script>

<style lang="scss">
@import "styles/appoint.scss";
</style>
